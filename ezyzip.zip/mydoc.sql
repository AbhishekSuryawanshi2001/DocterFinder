-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2023 at 07:22 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `id` int(10) NOT NULL,
  `u_card` varchar(12) NOT NULL,
  `u_f_name` text NOT NULL,
  `u_l_name` text NOT NULL,
  `u_father` text NOT NULL,
  `u_aadhar` varchar(12) NOT NULL,
  `u_birthday` text NOT NULL,
  `u_gender` varchar(6) NOT NULL,
  `u_email` text NOT NULL,
  `u_phone` varchar(10) NOT NULL,
  `u_state` varchar(12) NOT NULL,
  `u_dist` text NOT NULL,
  `u_village` text NOT NULL,
  `u_police` text NOT NULL,
  `u_pincode` text NOT NULL,
  `file` longblob NOT NULL,
  `u_mother` varchar(30) NOT NULL,
  `u_family` text NOT NULL,
  `staff_id` varchar(12) NOT NULL,
  `image` varchar(150) NOT NULL,
  `uploaded` datetime NOT NULL,
  `image1` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`id`, `u_card`, `u_f_name`, `u_l_name`, `u_father`, `u_aadhar`, `u_birthday`, `u_gender`, `u_email`, `u_phone`, `u_state`, `u_dist`, `u_village`, `u_police`, `u_pincode`, `file`, `u_mother`, `u_family`, `staff_id`, `image`, `uploaded`, `image1`) VALUES
(155, '233', 'Dr. akash', 'Deshmukh', 'Ram', '456465464561', '2023-07-17', 'Male', 'akashdeshmukh@gmail.com', '3232323232', 'Maharashtra', 'Amravati', 'Amravati', 'Sai nagar,amravati', '244344', '', 'physiologist', 'SAI HOSPITAL', 'MBBS', '7f1abb9dd834300a6b8019ceabc6858f.jpg', '2023-07-17 13:35:51', '7f1abb9dd834300a6b8019ceabc6858f.jpg'),
(156, '424', 'Dr. Ankita', 'Shinde', 'Suraj', '454554525551', '1999-02-22', 'Female', 'Ankitashinde@gmail.com', '5526511251', 'Maharashtra', 'Amravati', 'Amravati', 'Karve nagar,amravati', '154212', '', 'Cardiologist', 'Gajanan Hospital', 'MBBS 4 year', 'a44.jpg', '2023-07-17 16:14:51', '1109535.jpg'),
(157, '34342', 'Dr. Aniruddh', 'Patil', 'Y.', '456465464561', '1988-03-22', 'Male', 'Aniruddhpatil@gmail.com', '7754357546', 'Maharashtra', 'Amaravti', 'Amravati', 'Katora Naka,Amaravti', '215432', '', 'Dentist', 'Shree Hospital', 'Dental serge', 'nk.jpg', '2023-07-19 10:32:38', 'nk.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`id`, `username`, `password`, `email`, `create_at`) VALUES
(1, 'Abhishek', '$2y$10$UvAO2xTrnSWE3/fGcx3IbeTlFlSaRHYwIGRow0BDTmsReSoDvhg6e', 'suryawanshiabhishek099@gmail.com', '2023-07-21 02:50:49'),
(2, 'ajay', '$2y$10$l6Fop/0ork8RNSKqNCrMXeA6Gvo9uo0VQemLahBE5BQcXlIEB2626', 'ajaysuroshe@gmail.com', '2023-07-21 03:35:45'),
(3, 'shweta', '$2y$10$jmpzgI7wt4FioHR7G/jTT.86ps62yGbIno4A8kczISZZwirG7QTky', 'shwetanimbhorkar@gmail.com', '2023-07-21 08:39:55'),
(4, 'abhi', '$2y$10$gsyM4wbtRmmODiS5azE7aeeVYWt0P0XaOv7cYdlZBlumXhlYVETx.', 'abhi@gmail.com', '2023-07-21 09:12:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
